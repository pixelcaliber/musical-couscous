<?php

// define(''X-Session-ID'', 'X-Session-ID');
define('PORT', 8000);
define('USERNAME', 'username');
define('PASSWORD', 'password');
define('health_check', 'app_to_do_health_check');
define('login', 'app_to_do_login');
define('register', 'app_to_do_register');
define('to_do', 'app_to_do');
define('logout', 'app_to_do_logout');
define('add_task', 'app_to_do_add_task');
define('delete_task', 'app_to_do_delete_task');
define('archive_task', 'app_to_do_archive_task');
define('unarchive_task', 'app_to_do_unarchive_task');
